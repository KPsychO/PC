package Parte2.TieBreaker;

public class Var {
    int x;
    public Var() { this.x = 0;}
    public void inc () {this.x++;}
    public void dec () {this.x--;}
}