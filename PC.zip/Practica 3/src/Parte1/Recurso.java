package Parte1;

public class Recurso {
    int i;

    public Recurso(){
        this.i = 0;
    }

    public void incr(){
        this.i++;
    }

    public void decr(){
        this.i--;
    }

}
